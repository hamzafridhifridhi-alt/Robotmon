import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";

type Page =
  | "Overview"
  | "Gas Monitoring"
  | "Inertial Monitoring"
  | "Odometry"
  | "Alert History"
  | "Settings";
type Severity = "INFO" | "WARNING" | "CRITICAL";
type IconName =
  | "grid"
  | "gas"
  | "activity"
  | "route"
  | "bell"
  | "settings"
  | "wifi"
  | "mail"
  | "chevron"
  | "menu"
  | "x";

const navItems: { name: Page; icon: IconName }[] = [
  { name: "Overview", icon: "grid" },
  { name: "Gas Monitoring", icon: "gas" },
  { name: "Inertial Monitoring", icon: "activity" },
  { name: "Odometry", icon: "route" },
  { name: "Alert History", icon: "bell" },
  { name: "Settings", icon: "settings" },
];

const events: {
  time: string;
  source: string;
  event: string;
  severity: Severity;
  status: string;
}[] = [
  {
    time: "14:32:08.418",
    source: "MQ-2",
    event: "Reading returned below warning threshold",
    severity: "INFO",
    status: "Resolved",
  },
  {
    time: "14:29:44.102",
    source: "MQ-2",
    event: "Relative gas indication exceeded warning threshold",
    severity: "WARNING",
    status: "Resolved",
  },
  {
    time: "13:51:20.774",
    source: "IMU",
    event: "Pitch angle briefly exceeded 12° limit",
    severity: "WARNING",
    status: "Resolved",
  },
  {
    time: "12:08:11.063",
    source: "SYSTEM",
    event: "ESP32-S3 monitoring session started",
    severity: "INFO",
    status: "Logged",
  },
  {
    time: "11:44:39.501",
    source: "ENCODER-R",
    event: "Encoder response timeout",
    severity: "CRITICAL",
    status: "Resolved",
  },
  {
    time: "10:17:02.304",
    source: "SMTP",
    event: "Test notification delivered",
    severity: "INFO",
    status: "Sent",
  },
];

function Icon({ name, size = 17 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" />
        <rect x="14" y="3" width="7" height="7" />
        <rect x="3" y="14" width="7" height="7" />
        <rect x="14" y="14" width="7" height="7" />
      </>
    ),
    gas: (
      <>
        <path d="M12 22c4.4 0 8-3.3 8-7.4C20 9 12 2 12 2S4 9 4 14.6C4 18.7 7.6 22 12 22Z" />
        <path d="M8.5 16.5c1.8.8 4.6.8 7 0" />
      </>
    ),
    activity: <path d="M3 12h4l2.5-7 5 14 2.5-7h4" />,
    route: (
      <>
        <circle cx="6" cy="19" r="2" />
        <circle cx="18" cy="5" r="2" />
        <path d="M8 19h2a3 3 0 0 0 3-3V8a3 3 0 0 1 3-3" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
        <path d="M10 21h4" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V2.8h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
      </>
    ),
    wifi: (
      <>
        <path d="M5 12.6a10 10 0 0 1 14 0" />
        <path d="M8.5 16a5 5 0 0 1 7 0" />
        <path d="M2 9a15 15 0 0 1 20 0" />
        <circle cx="12" cy="20" r=".7" fill="currentColor" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="1" />
        <path d="m3 7 9 6 9-6" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    menu: (
      <>
        <path d="M4 7h16M4 12h16M4 17h16" />
      </>
    ),
    x: <path d="m6 6 12 12M18 6 6 18" />,
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function StatusDot({
  tone = "success",
  label,
}: {
  tone?: "success" | "warning" | "critical" | "neutral";
  label: string;
}) {
  return (
    <span className={`status-dot ${tone}`}>
      <i />
      {label}
    </span>
  );
}

function Panel({
  title,
  eyebrow,
  action,
  children,
  className = "",
}: {
  title?: string;
  eyebrow?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      {(title || action) && (
        <header className="panel-header">
          <div>
            {eyebrow && <span className="eyebrow">{eyebrow}</span>}
            <h3>{title}</h3>
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  );
}

function Metric({
  label,
  value,
  unit,
  sub,
  tone,
}: {
  label: string;
  value: string;
  unit?: string;
  sub?: string;
  tone?: string;
}) {
  return (
    <div className="metric">
      <span className="metric-label">{label}</span>
      <div className={`metric-value ${tone || ""}`}>
        {value}
        {unit && <small>{unit}</small>}
      </div>
      {sub && <span className="metric-sub">{sub}</span>}
    </div>
  );
}

const lineSets = {
  gas: "0,52 18,49 36,51 54,45 72,44 90,46 108,39 126,41 144,36 162,33 180,37 198,30 216,32 234,28 252,31 270,25 288,27 306,22 324,24",
  speed:
    "0,60 18,59 36,56 54,49 72,43 90,35 108,29 126,27 144,30 162,33 180,31 198,25 216,23 234,27 252,29 270,26 288,21 306,24 324,22",
  roll: "0,40 18,38 36,42 54,35 72,37 90,33 108,36 126,40 144,38 162,43 180,41 198,36 216,39 234,34 252,37 270,35 288,40 306,38 324,41",
  pitch:
    "0,46 18,44 36,41 54,43 72,40 90,42 108,39 126,36 144,39 162,35 180,38 198,40 216,37 234,41 252,39 270,42 288,38 306,40 324,37",
  accelX:
    "0,34 18,36 36,31 54,37 72,33 90,38 108,34 126,39 144,35 162,32 180,37 198,33 216,36 234,31 252,35 270,38 288,34 306,37 324,35",
  accelY:
    "0,47 18,44 36,48 54,43 72,46 90,42 108,47 126,44 144,49 162,45 180,42 198,46 216,43 234,48 252,44 270,46 288,42 306,45 324,43",
};

function Chart({
  lines = ["gas"],
  height = 112,
  labels = true,
}: {
  lines?: (keyof typeof lineSets)[];
  height?: number;
  labels?: boolean;
}) {
  const colors = ["#2563EB", "#D99520", "#16845B"];
  return (
    <div className="chart" style={{ height }}>
      <svg viewBox="0 0 324 76" preserveAspectRatio="none">
        {[15, 35, 55, 75].map((y) => (
          <line key={y} x1="0" y1={y} x2="324" y2={y} className="grid-line" />
        ))}
        {lines.map((line, i) => (
          <polyline
            key={line}
            points={lineSets[line]}
            fill="none"
            stroke={colors[i]}
            strokeWidth="1.8"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>
      {labels && (
        <div className="chart-labels">
          <span>14:10</span>
          <span>14:20</span>
          <span>14:30</span>
        </div>
      )}
    </div>
  );
}

function TiltIndicator({ large = false }: { large?: boolean }) {
  return (
    <div className={`tilt ${large ? "large" : ""}`}>
      <div className="tilt-axis x" />
      <div className="tilt-axis y" />
      <div className="tilt-ring r1" />
      <div className="tilt-ring r2" />
      <div className="tilt-plane">
        <span />
      </div>
      <div className="tilt-center" />
      <span className="tilt-label top">P +2.1°</span>
      <span className="tilt-label side">R −1.8°</span>
    </div>
  );
}

function EventTable({ rows = events }: { rows?: typeof events }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Timestamp</th>
            <th>Source</th>
            <th>Event</th>
            <th>Severity</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((event, i) => (
            <tr key={`${event.time}-${i}`}>
              <td className="mono">{event.time}</td>
              <td className="source">{event.source}</td>
              <td>{event.event}</td>
              <td>
                <span className={`severity ${event.severity.toLowerCase()}`}>{event.severity}</span>
              </td>
              <td>
                <span className="row-status">
                  <i />
                  {event.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PageIntro({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle: string;
  right?: ReactNode;
}) {
  return (
    <div className="page-intro">
      <div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {right}
    </div>
  );
}

function Overview({ tick, onViewAlerts }: { tick: number; onViewAlerts: () => void }) {
  const gas = 728 + (tick % 3) * 3;
  return (
    <>
      <PageIntro
        title="Robot Monitoring System"
        subtitle="Real-time environmental and motion monitoring"
        right={
          <div className="mode-note">
            <span>DEMO STREAM</span> API-ready interface
          </div>
        }
      />
      <div className="status-strip">
        <div className="status-primary">
          <span>Overall status</span>
          <strong>
            <i />
            NORMAL
          </strong>
        </div>
        <div>
          <span>Connected nodes</span>
          <strong>3 / 3</strong>
        </div>
        <div>
          <span>Last data update</span>
          <strong className="mono">{tick % 2 ? "0.4 s ago" : "0.8 s ago"}</strong>
        </div>
        <div>
          <span>Wi-Fi</span>
          <StatusDot label="Connected" />
        </div>
        <div>
          <span>SMTP service</span>
          <StatusDot label="Operational" />
        </div>
      </div>
      <div className="overview-grid">
        <Panel
          title="Gas monitoring"
          eyebrow="MQ-2 / ENVIRONMENT"
          action={<StatusDot label="Normal" />}
        >
          <div className="metrics two">
            <Metric
              label="Gas sensor reading"
              value={String(gas)}
              unit="ADC"
              sub="Relative indication"
            />
            <Metric label="ADC voltage" value="0.59" unit="V" sub="12-bit input" />
          </div>
          <div className="threshold-row">
            <span>
              Risk state <b>Normal</b>
            </span>
            <span>
              Warm-up <b>Complete</b>
            </span>
          </div>
          <Chart height={102} />
        </Panel>
        <Panel
          title="Inertial monitoring"
          eyebrow="IMU / MOTION"
          action={<StatusDot label="Stable" />}
        >
          <div className="imu-layout">
            <TiltIndicator />
            <div className="metrics two compact">
              <Metric label="Roll" value="−1.8" unit="°" />
              <Metric label="Pitch" value="+2.1" unit="°" />
              <Metric label="Accel X" value="0.04" unit="m/s²" />
              <Metric label="Accel Y" value="−0.07" unit="m/s²" />
              <Metric label="Accel Z" value="9.79" unit="m/s²" />
            </div>
          </div>
        </Panel>
        <Panel
          title="Odometry"
          eyebrow="DUAL ENCODER / DRIVE"
          action={<StatusDot label="Tracking" />}
        >
          <div className="metrics four">
            <Metric label="Left wheel" value="42.6" unit="RPM" />
            <Metric label="Right wheel" value="43.1" unit="RPM" />
            <Metric label="Total distance" value="18.42" unit="m" />
            <Metric label="Linear speed" value="0.31" unit="m/s" />
          </div>
          <Chart lines={["speed"]} height={105} />
        </Panel>
      </div>
      <Panel
        title="Recent events"
        eyebrow="SYSTEM LOG"
        action={
          <button className="text-button" onClick={onViewAlerts}>
            View all <Icon name="chevron" size={14} />
          </button>
        }
      >
        <EventTable rows={events.slice(0, 6)} />
      </Panel>
    </>
  );
}

function GasPage({ settings }: { settings: SettingsState }) {
  return (
    <>
      <PageIntro
        title="Gas Monitoring"
        subtitle="MQ-2 combustible gas and smoke sensor"
        right={<StatusDot label="Sensor online" />}
      />
      <div className="info-banner">
        <strong>Relative indication only</strong>
        <span>
          The MQ-2 is not calibrated for an accurate ppm measurement. Values shown are raw ADC and
          relative gas indications.
        </span>
      </div>
      <div className="metrics-grid six">
        <Metric label="Current ADC value" value="734" unit="/ 4095" sub="Live demo reading" />
        <Metric label="Analog voltage" value="0.59" unit="V" sub="Measured input" />
        <Metric label="Warning threshold" value={settings.gasWarning} unit="ADC" sub="Configured" />
        <Metric
          label="Critical threshold"
          value={settings.gasCritical}
          unit="ADC"
          sub="Configured"
        />
        <Metric label="Sensor warm-up" value="100" unit="%" sub="Complete" tone="success-text" />
        <Metric label="Calibration state" value="Relative" sub="Baseline established" />
      </div>
      <Panel
        title="Historical gas sensor reading"
        eyebrow="LAST 60 MINUTES"
        action={
          <div className="legend">
            <i /> ADC reading <b /> Warning threshold
          </div>
        }
      >
        <div className="plot-shell">
          <div className="y-labels">
            <span>1200</span>
            <span>900</span>
            <span>600</span>
            <span>300</span>
          </div>
          <Chart height={250} />
        </div>
      </Panel>
      <div className="two-col">
        <Panel title="Threshold status" eyebrow="ALARM LOGIC">
          <div className="progress-label">
            <span>Current relative indication</span>
            <strong>734 / {settings.gasCritical} ADC</strong>
          </div>
          <div className="progress">
            <i style={{ width: "46%" }} />
          </div>
          <div className="threshold-scale">
            <span>0</span>
            <span className="warn">Warning {settings.gasWarning}</span>
            <span className="crit">Critical {settings.gasCritical}</span>
          </div>
        </Panel>
        <Panel title="Sensor diagnostics" eyebrow="MQ-2 MODULE">
          <dl className="diagnostic-list">
            <div>
              <dt>Node address</dt>
              <dd>env/mq2/01</dd>
            </div>
            <div>
              <dt>Sampling interval</dt>
              <dd>500 ms</dd>
            </div>
            <div>
              <dt>Baseline ADC</dt>
              <dd>681</dd>
            </div>
            <div>
              <dt>Last calibration</dt>
              <dd>2025-03-04 09:12</dd>
            </div>
          </dl>
        </Panel>
      </div>
    </>
  );
}

function InertialPage() {
  return (
    <>
      <PageIntro
        title="Inertial Monitoring"
        subtitle="Robot orientation, acceleration and angular velocity"
        right={<StatusDot label="IMU stable" />}
      />
      <div className="imu-page-grid">
        <Panel title="Inclination" eyebrow="2-AXIS ATTITUDE">
          <TiltIndicator large />
          <div className="tilt-readouts">
            <Metric label="Roll angle" value="−1.8" unit="°" />
            <Metric label="Pitch angle" value="+2.1" unit="°" />
          </div>
        </Panel>
        <div className="sensor-stack">
          <Panel title="Linear acceleration" eyebrow="m/s²">
            <div className="metrics three">
              <Metric label="X axis" value="+0.04" unit="m/s²" />
              <Metric label="Y axis" value="−0.07" unit="m/s²" />
              <Metric label="Z axis" value="+9.79" unit="m/s²" />
            </div>
          </Panel>
          <Panel title="Angular velocity" eyebrow="°/s">
            <div className="metrics three">
              <Metric label="X axis" value="+0.12" unit="°/s" />
              <Metric label="Y axis" value="−0.08" unit="°/s" />
              <Metric label="Z axis" value="+0.03" unit="°/s" />
            </div>
          </Panel>
        </div>
      </div>
      <div className="two-col">
        <Panel
          title="Roll and pitch history"
          eyebrow="LAST 10 MINUTES"
          action={
            <div className="legend">
              <i /> Roll <b /> Pitch
            </div>
          }
        >
          <Chart lines={["roll", "pitch"]} height={220} />
        </Panel>
        <Panel
          title="Acceleration history"
          eyebrow="LAST 10 MINUTES"
          action={
            <div className="legend">
              <i /> X <b /> Y
            </div>
          }
        >
          <Chart lines={["accelX", "accelY"]} height={220} />
        </Panel>
      </div>
    </>
  );
}

function RobotSchematic() {
  return (
    <div className="robot-schematic">
      <div className="wheel left">
        <span>L</span>
      </div>
      <div className="robot-body">
        <div className="front-mark">FRONT</div>
        <div className="board">ESP32-S3</div>
        <i className="axis-line" />
      </div>
      <div className="wheel right">
        <span>R</span>
      </div>
      <div className="dimension">WHEEL SEPARATION · 284 mm</div>
    </div>
  );
}

function OdometryPage() {
  return (
    <>
      <PageIntro
        title="Odometry"
        subtitle="Differential-drive wheel encoder monitoring"
        right={<StatusDot label="Both encoders online" />}
      />
      <div className="metrics-grid seven">
        <Metric label="Left wheel" value="42.6" unit="RPM" sub="1,847 pulses" />
        <Metric label="Right wheel" value="43.1" unit="RPM" sub="1,862 pulses" />
        <Metric label="Left displacement" value="18.36" unit="m" />
        <Metric label="Right displacement" value="18.48" unit="m" />
        <Metric label="Estimated distance" value="18.42" unit="m" />
        <Metric label="Linear speed" value="0.31" unit="m/s" />
        <Metric label="Heading change" value="+1.2" unit="°" />
      </div>
      <div className="odometry-grid">
        <Panel title="Differential drive" eyebrow="TOP VIEW">
          <RobotSchematic />
        </Panel>
        <Panel title="Encoder pulse counters" eyebrow="CURRENT SESSION">
          <div className="counter">
            <span>LEFT / GPIO 14</span>
            <strong>001 284 773</strong>
            <small>Quadrature · 2048 PPR</small>
          </div>
          <div className="counter">
            <span>RIGHT / GPIO 15</span>
            <strong>001 291 042</strong>
            <small>Quadrature · 2048 PPR</small>
          </div>
        </Panel>
      </div>
      <div className="two-col">
        <Panel title="Linear speed history" eyebrow="LAST 10 MINUTES">
          <Chart lines={["speed"]} height={210} />
        </Panel>
        <Panel title="Estimated distance" eyebrow="CURRENT SESSION">
          <Chart lines={["gas"]} height={210} />
        </Panel>
      </div>
    </>
  );
}

function AlertPage() {
  const [severity, setSeverity] = useState("All severities");
  const [source, setSource] = useState("All sources");
  const filtered = events.filter(
    (e) =>
      (severity === "All severities" || e.severity === severity) &&
      (source === "All sources" || e.source === source),
  );
  const exportCsv = () => {
    const csv = [
      ["Timestamp", "Source", "Event", "Severity", "Status"],
      ...filtered.map((event) => [
        event.time,
        event.source,
        event.event,
        event.severity,
        event.status,
      ]),
    ]
      .map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(","))
      .join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "robotmon-events.csv";
    link.click();
    URL.revokeObjectURL(url);
  };
  return (
    <>
      <PageIntro
        title="Alert History"
        subtitle="System events and SMTP notification delivery"
        right={
          <button className="secondary-button" onClick={exportCsv}>
            Export CSV
          </button>
        }
      />
      <Panel className="filter-panel">
        <div className="filters">
          <label>
            Date range
            <select>
              <option>Today</option>
              <option>Last 7 days</option>
              <option>Last 30 days</option>
            </select>
          </label>
          <label>
            Source
            <select value={source} onChange={(e) => setSource(e.target.value)}>
              <option>All sources</option>
              <option>MQ-2</option>
              <option>IMU</option>
              <option>SYSTEM</option>
              <option>SMTP</option>
            </select>
          </label>
          <label>
            Severity
            <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
              <option>All severities</option>
              <option>INFO</option>
              <option>WARNING</option>
              <option>CRITICAL</option>
            </select>
          </label>
          <button
            className="secondary-button reset"
            onClick={() => {
              setSeverity("All severities");
              setSource("All sources");
            }}
          >
            Reset filters
          </button>
        </div>
      </Panel>
      <div className="alert-summary">
        <div>
          <span>Events today</span>
          <strong>6</strong>
        </div>
        <div>
          <span>Warnings</span>
          <strong className="amber">2</strong>
        </div>
        <div>
          <span>Critical</span>
          <strong className="red">1</strong>
        </div>
        <div>
          <span>SMTP delivered</span>
          <strong className="green">3 / 3</strong>
        </div>
      </div>
      <Panel
        title="Event log"
        eyebrow={`${filtered.length} MATCHING EVENTS`}
        action={<span className="last-sync">Last synced 14:32:09</span>}
      >
        <EventTable rows={filtered} />
      </Panel>
    </>
  );
}

type SettingsState = {
  gasWarning: string;
  gasCritical: string;
  hysteresis: string;
  calibration: string;
  incline: string;
  acceleration: string;
  diameter: string;
  resolution: string;
  gearRatio: string;
  separation: string;
  email: string;
  cooldown: string;
  notifications: boolean;
};

function Field({
  label,
  value,
  unit,
  type = "text",
  onChange,
}: {
  label: string;
  value: string;
  unit?: string;
  type?: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      <div>
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} />
        {unit && <em>{unit}</em>}
      </div>
    </label>
  );
}

function SettingsPage({
  settings,
  setSettings,
}: {
  settings: SettingsState;
  setSettings: (v: SettingsState) => void;
}) {
  const [saved, setSaved] = useState(false);
  const update = (key: keyof SettingsState, value: string | boolean) =>
    setSettings({ ...settings, [key]: value });
  const save = () => {
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };
  return (
    <>
      <PageIntro
        title="Settings"
        subtitle="Sensor thresholds, robot geometry and alert configuration"
        right={
          <div className="settings-actions">
            <span className={saved ? "save-confirm show" : "save-confirm"}>
              Configuration saved
            </span>
            <button className="primary-button" onClick={save}>
              Save configuration
            </button>
          </div>
        }
      />
      <div className="settings-grid">
        <Panel title="Gas sensor" eyebrow="MQ-2 THRESHOLDS">
          <div className="form-grid">
            <Field
              label="Warning threshold"
              value={settings.gasWarning}
              unit="ADC"
              onChange={(v) => update("gasWarning", v)}
            />
            <Field
              label="Critical threshold"
              value={settings.gasCritical}
              unit="ADC"
              onChange={(v) => update("gasCritical", v)}
            />
            <Field
              label="Alarm hysteresis"
              value={settings.hysteresis}
              unit="ADC"
              onChange={(v) => update("hysteresis", v)}
            />
            <Field
              label="Calibration status"
              value={settings.calibration}
              onChange={(v) => update("calibration", v)}
            />
          </div>
        </Panel>
        <Panel title="IMU limits" eyebrow="MOTION THRESHOLDS">
          <div className="form-grid">
            <Field
              label="Inclination warning"
              value={settings.incline}
              unit="degrees"
              onChange={(v) => update("incline", v)}
            />
            <Field
              label="Acceleration warning"
              value={settings.acceleration}
              unit="m/s²"
              onChange={(v) => update("acceleration", v)}
            />
          </div>
          <p className="form-note">
            Warnings are generated when the absolute value remains above a threshold for more than
            500 ms.
          </p>
        </Panel>
        <Panel title="Encoder geometry" eyebrow="ODOMETRY PARAMETERS">
          <div className="form-grid">
            <Field
              label="Wheel diameter"
              value={settings.diameter}
              unit="mm"
              onChange={(v) => update("diameter", v)}
            />
            <Field
              label="Encoder resolution"
              value={settings.resolution}
              unit="PPR"
              onChange={(v) => update("resolution", v)}
            />
            <Field
              label="Gear ratio"
              value={settings.gearRatio}
              unit=": 1"
              onChange={(v) => update("gearRatio", v)}
            />
            <Field
              label="Wheel separation"
              value={settings.separation}
              unit="mm"
              onChange={(v) => update("separation", v)}
            />
          </div>
        </Panel>
        <Panel title="Notifications" eyebrow="SMTP ALERT DELIVERY">
          <div className="form-grid">
            <Field
              label="Email recipient"
              value={settings.email}
              type="email"
              onChange={(v) => update("email", v)}
            />
            <Field
              label="Alert cooldown"
              value={settings.cooldown}
              unit="seconds"
              onChange={(v) => update("cooldown", v)}
            />
          </div>
          <label className="toggle-row">
            <span>
              <strong>Enable email notifications</strong>
              <small>Send warning and critical events through the configured SMTP service.</small>
            </span>
            <input
              type="checkbox"
              checked={settings.notifications}
              onChange={(e) => update("notifications", e.target.checked)}
            />
            <i />
          </label>
          <div className="secure-note">
            <Icon name="mail" size={16} />
            <span>
              SMTP credentials are stored on the ESP32-S3 and are never exposed in this interface.
            </span>
          </div>
        </Panel>
      </div>
    </>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("Overview");
  const mainRef = useRef<HTMLElement>(null);
  const [tick, setTick] = useState(0);
  const [now, setNow] = useState(new Date());
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [settings, setSettings] = useState<SettingsState>({
    gasWarning: "1100",
    gasCritical: "1600",
    hysteresis: "80",
    calibration: "Relative baseline",
    incline: "12",
    acceleration: "14.5",
    diameter: "138",
    resolution: "2048",
    gearRatio: "19.2",
    separation: "284",
    email: "lab.alerts@example.edu",
    cooldown: "120",
    notifications: true,
  });
  useEffect(() => {
    const timer = window.setInterval(() => {
      setNow(new Date());
      setTick((t) => t + 1);
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);
  const content = useMemo(() => {
    if (page === "Overview")
      return <Overview tick={tick} onViewAlerts={() => setPage("Alert History")} />;
    if (page === "Gas Monitoring") return <GasPage settings={settings} />;
    if (page === "Inertial Monitoring") return <InertialPage />;
    if (page === "Odometry") return <OdometryPage />;
    if (page === "Alert History") return <AlertPage />;
    return <SettingsPage settings={settings} setSettings={setSettings} />;
  }, [page, settings, tick]);
  const navigate = (name: Page) => {
    setPage(name);
    mainRef.current?.scrollTo({ top: 0 });
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <span />
            <i />
          </div>
          <div>
            <strong>
              ROBOT<span>MON</span>
            </strong>
            <small>ENGINEERING CONSOLE</small>
          </div>
        </div>
        <nav>
          {navItems.map((item) => (
            <button
              key={item.name}
              className={page === item.name ? "active" : ""}
              onClick={() => navigate(item.name)}
            >
              <Icon name={item.icon} />
              <span>{item.name}</span>
              {page === item.name && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="connection-head">
            <span>CONTROLLER</span>
            <StatusDot label="ONLINE" />
          </div>
          <div className="device-name">
            ESP32-S3 <small>central-01</small>
          </div>
          <dl>
            <div>
              <dt>Address</dt>
              <dd>192.168.4.32</dd>
            </div>
            <div>
              <dt>Network</dt>
              <dd>
                <Icon name="wifi" size={13} />
                LAB-ROBOTICS
              </dd>
            </div>
            <div>
              <dt>Firmware</dt>
              <dd>v1.4.2</dd>
            </div>
          </dl>
        </div>
      </aside>
      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <span className="breadcrumb">
              MONITOR / <strong>{page.toUpperCase()}</strong>
            </span>
          </div>
          <div className="topbar-right">
            <div className="system-state">
              <i />
              SYSTEM NORMAL
            </div>
            <time>
              <strong>{now.toLocaleTimeString("en-GB")}</strong>
              <span>
                {now
                  .toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })
                  .toUpperCase()}
              </span>
            </time>
            <div className="notification-wrap">
              <button
                className="notification"
                aria-label="Notifications"
                onClick={() => setNoticeOpen(!noticeOpen)}
              >
                <Icon name="bell" />
                <i />
              </button>
              {noticeOpen && (
                <div className="notice-popover">
                  <strong>Notifications</strong>
                  <p>No active alarms</p>
                  <span>All monitored systems are operating within configured limits.</span>
                </div>
              )}
            </div>
          </div>
        </header>
        <main ref={mainRef}>{content}</main>
        <footer className="app-footer">
          <span>ROBOTMON engineering console · demo interface</span>
          <span>
            REST endpoint <code>/api/v1/telemetry</code>
          </span>
        </footer>
      </div>
    </div>
  );
}
